package com.mfeltontp1;

import com.mfeltontp1.model.Citoyen;
import static org.junit.jupiter.api.Assertions.*;

import com.mfeltontp1.services.CitoyenService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.function.BooleanSupplier;

@SpringBootTest
public class CitoyenServiceTets {

    @Autowired
    CitoyenService citoyenService;

    @Test
    @DisplayName("Test login")
    public void testLogin() {
        Citoyen cit = new Citoyen();
        cit.setCourriel("toto@gmail.com"); cit.setPassword("Toto1234");
        String inputLogin = "toto@gmail.com"; String inputPassword = "Toto1234";

        assertNotNull(citoyenService.login(inputLogin,inputPassword));
    }

}
