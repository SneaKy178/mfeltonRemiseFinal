package com.mfeltontp1.repositories;

import com.mfeltontp1.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdminRepository  extends JpaRepository<Admin,Integer> {

    public Admin findAdminByIdUser(int id);

    public List<Admin> findAdminByRole(String role);

}
