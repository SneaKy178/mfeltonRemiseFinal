package com.mfeltontp1.services;

import com.mfeltontp1.model.Admin;

import org.springframework.stereotype.Service;

@Service
public class AdminService {

    public boolean login(Admin admin, String inputLogin, String inputPwd) {
        return admin.getCourriel().equals(inputLogin) && admin.getPassword().equals(inputPwd);
    }
}
