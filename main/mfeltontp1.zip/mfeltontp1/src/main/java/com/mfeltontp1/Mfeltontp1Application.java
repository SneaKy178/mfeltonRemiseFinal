package com.mfeltontp1;


import com.mfeltontp1.repositories.PermisRepository;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.LocalDate;


@SpringBootApplication
@EnableScheduling
@Log
public class Mfeltontp1Application   {

    @Autowired
    PermisRepository permisRepository;

    public static void main(String[] args) {
        SpringApplication.run(Mfeltontp1Application.class, args);
    }

    @Scheduled(cron = "0 0 02 ? * *")
    public void doSomething(){
        log.info("certains permis sont maintenant expired : " + permisRepository.permisExpired(LocalDate.now()));
    }

}
