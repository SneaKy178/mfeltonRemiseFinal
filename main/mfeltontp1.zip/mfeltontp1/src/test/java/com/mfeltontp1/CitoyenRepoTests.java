package com.mfeltontp1;

import com.mfeltontp1.model.Citoyen;
import com.mfeltontp1.repositories.CitoyenRepository;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@DataJpaTest
public class CitoyenRepoTests {

    @Autowired
    CitoyenRepository citoyenRepository;

//    @BeforeAll
//    public void dataTest(){
//        Citoyen citoyen = new Citoyen();
//        citoyen.setCourriel("toto@gmail.com"); citoyen.setPassword("Toto1234");
//        citoyen.setNumAssuranceMaladie("4D5C7CS4");
//        citoyen.setNom("Toto");
//        citoyen.setPrenom("Tata");
//        citoyen.setSexe("Homme");
//        citoyen.setAge(20);
//        citoyen.setNumTelephone("514-946-1234");
//        citoyen.setVilleResidence("Chateaguay");
//        citoyen.setParentOuTuteur(true);
//        citoyen.setMineur(false);
//
//        citoyenRepository.saveAll(Arrays.asList(citoyen));
//
//
//
//    }

    @Test
    @DisplayName("findCitoyenByIdUser")
    public void testIdUser(){
        assertEquals(citoyenRepository.findAll().size(), 1);
    }

    @Test
    @DisplayName("findCitoyenByNumAssuranceMaladie")
    public void testNassm() {
        assertEquals(citoyenRepository.findAll().size(), 1);
    }

    @Test
    @DisplayName("findCitoyenByNom")
    public void testNom() {
        assertEquals(citoyenRepository.findAll().size(), 1);
    }

    @Test
    @DisplayName("findCitoyenBySexe")
    public void testSexe(){
        assertEquals(citoyenRepository.findAll().size(), 1);
    }

    @Test
    @DisplayName("findCitoyenByAge")
    public void testAge() {
        assertEquals(citoyenRepository.findAll().size(), 1);
    }

    @Test
    @DisplayName("findCitoyenByNumTelephone")
    public void testTelephone() {
        assertEquals(citoyenRepository.findAll().size(), 1);
    }

    @Test
    @DisplayName("findCitoyenByVilleResidence")
    public void testResidence(){
        assertEquals(citoyenRepository.findAll().size(), 1);
    }

    @Test
    @DisplayName("findCitoyenByCourrielIgnoreCase")
    public void testCourriel(){
        assertEquals(citoyenRepository.findAll().size(), 1);
    }





}
