package com.adminapp.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Data
public class Permis implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idPermis;

    private String typePermis;

    private LocalDate datePermis;

    private LocalDate finDatePermis;

    private String isExpired;

    private String veutRenew;

    public Permis(String typePermis){
        this.typePermis = typePermis;
        datePermis = LocalDate.now();
        finDatePermis = LocalDate.now().plusDays(15);
        isExpired = "false";
        veutRenew = "false";

    }

    public Permis(){
    }


}
