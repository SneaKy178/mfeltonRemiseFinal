package com.adminapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
