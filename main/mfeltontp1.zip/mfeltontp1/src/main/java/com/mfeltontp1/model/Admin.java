package com.mfeltontp1.model;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import java.io.Serializable;

@Entity
@Data
public class Admin extends User implements Serializable{


    private String role;

    public Admin(){
        super();
    }

    public Admin( String courriel, String password, String role) {
        super(courriel, password);
        this.role = role;
    }
}
