import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Permis } from '../model/permis';
import { GenericService } from './genericService';

@Injectable({
  providedIn: 'root'
})
export class CitoyenPermisService extends GenericService<Permis,Number> {

  constructor(http: HttpClient) { 
    super(http, 'http://localhost:9090/citoyen')
  }

  public userIsLogIn(){
    let email = sessionStorage.getItem('courriel');
    return email != null;
  }

  public logOut(){
    sessionStorage.clear();
  }

}
