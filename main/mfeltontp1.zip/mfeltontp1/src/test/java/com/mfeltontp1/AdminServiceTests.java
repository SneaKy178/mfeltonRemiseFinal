package com.mfeltontp1;

import com.mfeltontp1.model.Admin;
import com.mfeltontp1.services.AdminService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class AdminServiceTests {

    @Autowired
    AdminService adminService;

    @Test
    @DisplayName("Test login")
    public void testLogin(){
        Admin admin = new Admin();
        admin.setCourriel("toto@gmail.com"); admin.setPassword("Toto1234");
        String inputLogin = "toto@gmail.com"; String inputPassword = "Toto1234";

        assertTrue(adminService.login(admin,inputLogin,inputPassword));
    }
}
