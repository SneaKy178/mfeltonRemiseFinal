import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Error404Component } from './components/error404/error404.component';
import { LoginComponent } from './components/login/login.component';
import { LogoutComponent } from './components/logout/logout.component';
import { SubscribeComponent } from './components/subscribe/subscribe.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HomeComponent } from './components/home/home.component';
import { FooterComponent } from './components/footer/footer.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ValidityNassmComponent } from './components/validity-nassm/validity-nassm.component';
import { ModifyCitoyenComponent } from './components/modify-citoyen/modify-citoyen.component';

@NgModule({
  declarations: [
    AppComponent,
    Error404Component,
    LoginComponent,
    LogoutComponent,
    SubscribeComponent,
    DashboardComponent,
    HomeComponent,
    FooterComponent,
    NavbarComponent,
    ValidityNassmComponent,
    ModifyCitoyenComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
