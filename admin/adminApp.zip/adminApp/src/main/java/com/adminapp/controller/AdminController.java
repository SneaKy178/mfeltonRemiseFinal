package com.adminapp.controller;

import com.adminapp.model.Citoyen;
import com.adminapp.model.Permis;
import com.adminapp.repository.CitoyenRepository;
import com.adminapp.repository.PermisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AdminController {

    @Autowired
    CitoyenRepository citoyenRepository;

    @Autowired
    PermisRepository permisRepository;


    @RequestMapping(path = "/")
    public String index() {
        return "index";
    }

    @GetMapping(path = "/citoyens")
    public String getCitoyens(Model model){
        model.addAttribute("listCitoyens", citoyenRepository.findAll());
            return  "citoyens";
    }

    @GetMapping("/citoyens/edit/{id}")
    public String editCitoyen(Model model, @PathVariable(value = "id") Integer id){
        model.addAttribute("citoyen", citoyenRepository.findCitoyenByIdUser(id));
        return "citoyensEdit";
    }

    @PostMapping("/citoyen/update")
    public String updateCitoyen(@ModelAttribute Citoyen citoyen){
        Permis permis = citoyenRepository.findCitoyenByIdUser(citoyen.getIdUser()).getPermis();
        citoyen.setPermis(permis);
        citoyenRepository.save(citoyen);
        return "redirect:/citoyens";
    }


    @GetMapping("/citoyens/delete/{id}")
    public String deletePermit(Model model, @PathVariable(value = "id") Integer id){
        citoyenRepository.deleteById(id);
        return "redirect:/citoyens";
    }

    @GetMapping(path = "/permis")
    public String getPermis(Model model){
        model.addAttribute("listPermis", permisRepository.findAll());
        return  "permis";
    }



}
