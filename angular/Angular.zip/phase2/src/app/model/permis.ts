export class Permis{
    idPermis : number;
    typePermis : string;
    datePermis : Date;
    finDatePermis : Date;
    isExpired : string;
    veutRenew : string;
}