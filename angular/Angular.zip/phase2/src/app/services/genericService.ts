import { Observable } from "rxjs";
import { HttpClient } from '@angular/common/http';
import { Citoyen } from "../model/citoyen";

export class GenericService<T, ID>{
    constructor(protected http: HttpClient, protected url: string){

    }

    create(t: T): Observable<T> {
      return this.http.post<T>(this.url, t);
    }

    getAll(): Observable<T[]> {
      return this.http.get<T[]>(this.url);
    }

    findById(id: ID): Observable<T> {
      return this.http.get<T>(this.url + "/" + id);
    }
    
    checkCitizenValidity(nassm: string): Observable<boolean> {
      return this.http.get<boolean>(this.url + "/" + nassm);
    }
    
    updateCitoyen(t: T): Observable<T> {
      return this.http.post<T>(this.url + "/update", t);
    }

    updatePermis(t: T): Observable<T> {
      return this.http.post<T>(this.url + "/updatePermis", t);
    }

    login(courriel: string, password: string): Observable<T>{
      return this.http.get<T>(this.url + "/" + courriel + "/" + password)
    }

    sendEmail(t: T): Observable<T> {
      return this.http.post<T>(this.url + "/email", t)
    }

    update(id: ID, t: T): Observable<T> {
      return this.http.put<T>(this.url + "/" + id, t, {});
    }

    deleteById(id: ID): Observable<T> {
      return this.http.delete<T>(this.url + "/" + id);
    }
}