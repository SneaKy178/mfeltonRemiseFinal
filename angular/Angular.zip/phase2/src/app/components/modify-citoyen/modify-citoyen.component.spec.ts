import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyCitoyenComponent } from './modify-citoyen.component';

describe('ModifyCitoyenComponent', () => {
  let component: ModifyCitoyenComponent;
  let fixture: ComponentFixture<ModifyCitoyenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModifyCitoyenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyCitoyenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
