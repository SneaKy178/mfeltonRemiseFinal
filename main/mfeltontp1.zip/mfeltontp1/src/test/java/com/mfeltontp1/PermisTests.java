package com.mfeltontp1;

import com.mfeltontp1.model.Permis;
import com.mfeltontp1.repositories.PermisRepository;
import org.hibernate.validator.internal.util.privilegedactions.LoadClass;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;


@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@DataJpaTest
public class PermisTests {

    @Autowired
    PermisRepository permisRepository;

    @BeforeAll
    public  void dataTest(){
        Permis permis = new Permis();
        permis.setTypePermis("VACCIN");
        permis.setVeutRenew("true");
        permis.setDatePermis(LocalDate.of(2021, Month.MARCH,26));

        Permis permis2 = new Permis();
        permis2.setTypePermis("TEST");
        permis2.setVeutRenew("false");
        permis2.setDatePermis(LocalDate.of(2021, Month.MARCH,27));


        permisRepository.saveAll(Arrays.asList(permis,permis2));
    }


    @Test
    @DisplayName("findPermisByIdPermis")
    public void testId(){
        assertEquals(permisRepository.findAll().size(),2);
    }


    @Test
    @DisplayName("findPermisByTypePermis")
    public void testTypePermis() {


        assertEquals(permisRepository.findAll().size(), 2);
    }

    @Test
    @DisplayName("findPermisByValidityPermisAfter")
    public void testDateAfter(){
        LocalDate date = LocalDate.of(2020, Month.APRIL,1);

        assertEquals(permisRepository.findPermisByDatePermisAfter(date).size(),2);
    }

    @Test
    @DisplayName("findPermisByValidityPermisBefore")
    public void testDateBefore(){
        LocalDate date = LocalDate.of(2021, Month.APRIL,1);

        assertEquals(permisRepository.findPermisByDatePermisBefore(date).size(),2);
    }

    @Test
    @DisplayName("findPermisByValidityPermisBetween")
    public void testDateBetween(){

        LocalDate date = LocalDate.of(2021,Month.MARCH,20);
        LocalDate date2 = LocalDate.of(2021,Month.MARCH,31);

        assertEquals(permisRepository.findPermisByDatePermisBetween(date,date2).size(),2);

    }



}
