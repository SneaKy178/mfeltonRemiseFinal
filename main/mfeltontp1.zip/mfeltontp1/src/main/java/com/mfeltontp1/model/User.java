package com.mfeltontp1.model;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@MappedSuperclass
@Data
public class User implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idUser;

    private String courriel;

    private String password;

    public User(){

    }

    public User(String courriel, String password){
        this.courriel = courriel;
        this.password = password;
    }

}
