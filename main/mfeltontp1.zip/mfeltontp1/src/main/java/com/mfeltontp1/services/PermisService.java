package com.mfeltontp1.services;


import com.mfeltontp1.model.Permis;
import com.mfeltontp1.repositories.PermisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;


@Service
public class PermisService {

    @Autowired
    PermisRepository repository;


    public Permis updateDateExpiration(Permis permis){
        permis.setFinDatePermis(permis.getFinDatePermis().plusDays(14));
        permis.setIsExpired("FALSE");
        return repository.save(permis);
    }





}
