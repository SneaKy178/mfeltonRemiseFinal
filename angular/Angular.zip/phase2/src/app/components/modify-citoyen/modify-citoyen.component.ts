import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Citoyen } from 'src/app/model/citoyen';
import { Permis } from 'src/app/model/permis';
import { CitoyenPermisService } from 'src/app/services/citoyen-permis.service';
import { PermisService } from 'src/app/services/permis.service';

@Component({
  selector: 'app-modify-citoyen',
  templateUrl: './modify-citoyen.component.html',
  styleUrls: ['./modify-citoyen.component.css']
})
export class ModifyCitoyenComponent implements OnInit {

  citoyen : Citoyen;
  permis :  Permis;
  validMessage: string = "";
  flag: boolean;
  mineur : string;

  constructor(private service: PermisService, private route: Router) { }

  ngOnInit(): void {
    this.citoyen = history.state;
    this.mineur = this.citoyen.isMineur;
    this.permis = this.citoyen.permis;
  }

  modifyForm = new FormGroup({
    idUser: new FormControl('', Validators.required),
    nassm: new FormControl('', Validators.required),
    courriel: new FormControl('', Validators.required),
    prenom: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
    nom: new FormControl('', Validators.required),
    sexe: new FormControl('', Validators.required),
    age: new FormControl('', Validators.required),
    numTelephone: new FormControl('', Validators.required),
    villeResidence: new FormControl('', Validators.required),
    isParentOuTuteur: new FormControl('', Validators.required),
    isMineur: new FormControl('', Validators.required),
    idParent: new FormControl(0, Validators.required)
  });

  
  onUpdateCitoyen(){
    if (this.modifyForm.valid){
      this.citoyen = this.modifyForm.value
      console.log(this.permis);
      this.citoyen.permis = this.permis;
      this.service.updateCitoyen(this.citoyen).subscribe(
        (data) => {
          if(data != null) {
            this.modifyForm.reset();
          this.route.navigateByUrl('/login');
          } else {
            this.validMessage = 'cannot subscribe';
          }
        },
        (err) => {
          console.log(err);
        }
      );
    } else {
      this.validMessage = "Please fill the form";
    }
  }

  


}
