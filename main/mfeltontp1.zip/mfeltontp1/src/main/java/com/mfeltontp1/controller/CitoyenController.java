package com.mfeltontp1.controller;

import com.mfeltontp1.model.Citoyen;
import com.mfeltontp1.model.Permis;
import com.mfeltontp1.repositories.CitoyenRepository;
import com.mfeltontp1.services.CitoyenService;
import com.mfeltontp1.services.PermisService;
import com.mfeltontp1.services.SystemService;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

@RestController
@CrossOrigin(origins = {"http://localhost:4222","http://localhost:9696"})
public class CitoyenController {

    @Autowired
    CitoyenService citoyenService;

    @Autowired
    SystemService systemService;

    @Autowired
    PermisService permisService;

    @Autowired
    CitoyenRepository repository;

    //@RequestMapping(value = "/ministere/{email} && {password", method = RequestMethod.GET)
    @GetMapping("/citoyen/{email}/{password}")
    public Citoyen login(@PathVariable("email") String email, @PathVariable("password") String password){
        return citoyenService.login(email,password);
    }

    @PostMapping("/citoyen")
    public Citoyen subscribe(@RequestBody Citoyen citoyen){
        return citoyenService.addCitoyen(citoyen);
    }

    @PostMapping("/citoyen/update")
    public Citoyen updateCitoyen(@RequestBody Citoyen citoyen){
        return citoyenService.updateCitoyen(citoyen);
    }

    @PostMapping("/citoyen/email")
    public boolean send(@RequestBody Citoyen citoyen) throws Exception {
        return systemService.generateQrPdf(citoyen);
    }

    @PostMapping("/citoyen/updatePermis")
    public Permis updatePermis(@RequestBody Permis permis){
        return permisService.updateDateExpiration(permis);
    }

    @GetMapping("/citoyen/qrcode/{nassm}")
    public void getPermisQrCode(@PathVariable String nassm, HttpServletResponse response) throws IOException {
        response.setContentType("image/jpeg");

        Citoyen citoyen = repository.findCitoyenByNassm(nassm);

        InputStream inputStream = new ByteArrayInputStream(systemService.getQrCitoyenByte(citoyen));
        IOUtils.copy(inputStream, response.getOutputStream());
    }
}
