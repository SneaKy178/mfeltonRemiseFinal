package com.ministere.service;

import com.ministere.model.Citoyen;
import com.ministere.repository.CitoyenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MinistereService {

    @Autowired
    CitoyenRepository repository;

    public boolean checkCitoyenValidity(String nassm){
        boolean flag = false;
        Citoyen citoyen = repository.findCitoyenByNassmIgnoreCase(nassm);
                    if(citoyen != null && citoyen.isValid()){
                        flag = true;
                }
                return flag;
    }


    public String getTypeCitoyen(String nassm){
        Citoyen citoyen = repository.findCitoyenByNassmIgnoreCase(nassm);
        if(citoyen != null){
          return citoyen.getType();
        }
        return null;
    }


}
