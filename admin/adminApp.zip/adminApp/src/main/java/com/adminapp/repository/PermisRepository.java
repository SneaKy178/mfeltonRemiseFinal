package com.adminapp.repository;


import com.adminapp.model.Permis;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PermisRepository extends JpaRepository<Permis, Integer> {

    public Permis findPermisByIdPermis(int id);

    public List<Permis> findPermisByTypePermis(String type);

    public List<Permis>  findPermisByDatePermisAfter(LocalDate date);
    public List<Permis>  findPermisByDatePermisBefore(LocalDate date);
    public List<Permis>  findPermisByDatePermisBetween(LocalDate date1, LocalDate date2);


}
